package com.br.sitevenhajunto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiteVenhaJuntoApplicationTests {

	@Test
	void contextLoads() {
	}

}
